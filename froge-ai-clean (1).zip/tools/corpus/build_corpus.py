"""Build a text corpus (encyclopedia + recipes + web + books) as JSONL.

Outputs in --out (default data/corpus/):
  corpus.jsonl            {"source","title","text","license"}  raw text for pretraining
  instructions.jsonl      {"instruction","response"}  for train.py --extra
  SOURCES.md              what went in, with licences

Examples:
  python tools/corpus/build_corpus.py --test --to-datasets      # tiny run: 200 items per source
  python tools/corpus/build_corpus.py --wiki 50000 --web 50000 --books 300 --recipes_csv full_dataset.csv --recipes 50000 --to-datasets
Sources are STREAMED, so only what you ask for is downloaded.
"""
import argparse, ast, csv, hashlib, json, os, random, re, sys

LICENSES = {
 "wikipedia": "CC BY-SA 3.0 / GFDL (attribution + share-alike)",
 "fineweb-edu": "ODC-By 1.0 (attribution); underlying pages keep their own copyright",
 "gutenberg": "Public domain in the US (check each book; some may not be in your country)",
 "recipes": "RecipeNLG: NO KNOWN LICENSE - research use only, check its terms",
}

def clean(t):
    t = t.replace("\r", "")
    t = re.sub(r"[ \t]+", " ", t)
    return re.sub(r"\n{3,}", "\n\n", t).strip()

def chunks(text, size=2000):
    """Split long text (books) on paragraph breaks into ~size-char pieces."""
    out, cur = [], ""
    for p in text.split("\n\n"):
        if len(cur) + len(p) > size and cur:
            out.append(cur.strip()); cur = ""
        cur += p + "\n\n"
    if len(cur.strip()) > 300: out.append(cur.strip())
    return out

def strip_gutenberg(t):
    m = re.search(r"\*\*\* ?START OF (THE|THIS) PROJECT GUTENBERG.*?\*\*\*", t)
    if m: t = t[m.end():]
    m = re.search(r"\*\*\* ?END OF (THE|THIS) PROJECT GUTENBERG", t)
    if m: t = t[:m.start()]
    return t

def wiki_rows(r):
    title, text = r["title"], clean(r["text"])
    if len(text) < 500: return [], []
    paras = [p for p in text.split("\n\n") if p.strip()]
    intro = "\n\n".join(paras[:2])[:1500]
    corpus = [{"source": "wikipedia", "title": title, "text": text, "license": LICENSES["wikipedia"]}]
    inst = [{"instruction": f"Tell me about {title}.", "response": intro}]
    return corpus, inst

def web_rows(r):
    text = clean(r["text"])
    if len(text) < 400: return [], []
    return [{"source": "fineweb-edu", "title": r.get("url", ""), "text": text, "license": LICENSES["fineweb-edu"]}], []

def book_rows(r):
    text = strip_gutenberg(clean(r["TEXT"]))
    meta = r.get("METADATA", "")
    try: title = json.loads(meta).get("title", "")
    except Exception: title = ""
    corpus = [{"source": "gutenberg", "title": title, "text": c, "license": LICENSES["gutenberg"]}
              for c in chunks(text)[:40]]   # cap chunks per book so no single book dominates
    return corpus, []

def _as_list(x):
    if isinstance(x, list): return x
    try: return list(ast.literal_eval(x))
    except Exception: return [s for s in str(x).split("\n") if s.strip()]

def recipe_rows(r):
    title = clean(r.get("title", ""))
    ing, steps = _as_list(r.get("ingredients", "[]")), _as_list(r.get("directions", "[]"))
    if not title or not ing or not steps: return [], []
    body = ("Ingredients:\n" + "\n".join(f"- {i}" for i in ing) +
            "\n\nDirections:\n" + "\n".join(f"{n}. {s}" for n, s in enumerate(steps, 1)))
    return ([{"source": "recipes", "title": title, "text": f"{title}\n\n{body}", "license": LICENSES["recipes"]}],
            [{"instruction": f"How do I make {title}?", "response": body}])

def run(stream, fn, limit, corpus_f, inst_f, seen, label):
    n = kept = 0
    for r in stream:
        if kept >= limit: break
        n += 1
        c, i = fn(r)
        if not c: continue
        h = hashlib.md5(c[0]["text"][:500].encode("utf-8", "ignore")).hexdigest()
        if h in seen: continue               # skip duplicates
        seen.add(h); kept += 1
        for x in c: corpus_f.write(json.dumps(x, ensure_ascii=False) + "\n")
        for x in i: inst_f.write(json.dumps(x, ensure_ascii=False) + "\n")
        if kept % 1000 == 0: print(f"  {label}: {kept}/{limit}", flush=True)
    print(f"{label}: kept {kept} (read {n})")
    return kept

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--wiki", type=int, default=20000)
    ap.add_argument("--wiki_config", default="20231101.en", help="use 20231101.simple for a small test")
    ap.add_argument("--web", type=int, default=20000)
    ap.add_argument("--books", type=int, default=100)
    ap.add_argument("--recipes", type=int, default=20000)
    ap.add_argument("--recipes_csv", default="", help="RecipeNLG full_dataset.csv (manual download)")
    ap.add_argument("--out", default="data/corpus")
    ap.add_argument("--to-datasets", action="store_true", help="also copy instructions.jsonl into data/datasets so the AI can search it")
    ap.add_argument("--test", action="store_true")
    a = ap.parse_args()
    if a.test: a.wiki, a.web, a.books, a.recipes, a.wiki_config = 200, 200, 5, 200, "20231101.simple"
    from datasets import load_dataset
    os.makedirs(a.out, exist_ok=True)
    seen, stats = set(), {}
    with open(f"{a.out}/corpus.jsonl", "w", encoding="utf-8") as cf, \
         open(f"{a.out}/instructions.jsonl", "w", encoding="utf-8") as inf:
        if a.wiki:
            s = load_dataset("wikimedia/wikipedia", a.wiki_config, split="train", streaming=True).shuffle(seed=1, buffer_size=10000)
            stats["wikipedia"] = run(s, wiki_rows, a.wiki, cf, inf, seen, "wikipedia")
        if a.web:
            s = load_dataset("HuggingFaceFW/fineweb-edu", "sample-10BT", split="train", streaming=True)
            stats["fineweb-edu"] = run(s, web_rows, a.web, cf, inf, seen, "web")
        if a.books:
            s = load_dataset("sedthh/gutenberg_english", split="train", streaming=True)
            stats["gutenberg"] = run(s, book_rows, a.books, cf, inf, seen, "books")
        if a.recipes and a.recipes_csv:
            def rd():
                with open(a.recipes_csv, encoding="utf-8", newline="") as f:
                    yield from csv.DictReader(f)
            stats["recipes"] = run(rd(), recipe_rows, a.recipes, cf, inf, seen, "recipes")
        elif a.recipes:
            print("Recipes skipped: pass --recipes_csv (download RecipeNLG yourself and read its terms).")
    with open(f"{a.out}/SOURCES.md", "w") as f:
        f.write("# Sources in this corpus\n\n")
        for k, v in stats.items(): f.write(f"- {k}: {v} items - {LICENSES[k]}\n")
    if a.to_datasets:
        import shutil
        os.makedirs("data/datasets", exist_ok=True)
        shutil.copy(f"{a.out}/instructions.jsonl", "data/datasets/corpus_instructions.jsonl")
        print("copied instructions.jsonl -> data/datasets/corpus_instructions.jsonl")
    print("done ->", a.out)

if __name__ == "__main__":
    main()
