import build_corpus as b, io, json
# fake rows (no network)
c,i=b.wiki_rows({"title":"Tea","text":("Tea is a drink.\n\n"+"It is made from leaves. "*30+"\n\nMore.")})
assert c and i and i[0]["instruction"]=="Tell me about Tea."
c,i=b.recipe_rows({"title":"Pancakes","ingredients":"['1 cup flour','1 egg']","directions":"['Mix.','Fry.']"})
assert "1. Mix." in i[0]["response"] and "- 1 egg" in c[0]["text"]
assert b.recipe_rows({"title":"","ingredients":"[]","directions":"[]"})==([],[])
txt="junk\n*** START OF THE PROJECT GUTENBERG EBOOK X ***\n"+("Para one text here. "*40+"\n\n")*8+"*** END OF THE PROJECT GUTENBERG EBOOK X ***\nlicense"
c,_=b.book_rows({"TEXT":txt,"METADATA":json.dumps({"title":"X"})})
assert c and "license" not in c[-1]["text"] and "junk" not in c[0]["text"]
assert b.web_rows({"text":"short"})==([],[])
cf,inf=io.StringIO(),io.StringIO(); seen=set()
rows=[{"title":"A","text":"x "*400}]*3
k=b.run(iter(rows),b.wiki_rows,10,cf,inf,seen,"t"); assert k==1   # duplicates dropped
print("all logic tests passed")
