# Corpus Builder: encyclopedia + recipes + web + books

## Run
    pip install datasets
    python tools/corpus/build_corpus.py --test          # small check first (about 200 items per source)
    python tools/corpus/build_corpus.py --wiki 50000 --web 50000 --books 300 --to-datasets

Output (in data/corpus/):
- corpus.jsonl        raw text for pretraining: source, title, text, license
- instructions.jsonl  question/answer pairs (Wikipedia "Tell me about X", recipes "How do I make X?")
  -> or run with --to-datasets so the AI can search it
- SOURCES.md          counts and licences

Data is streamed, so only the amount you ask for is downloaded. Duplicates are skipped.

## Sources
| Part | Dataset | Size | Licence |
|---|---|---|---|
| Encyclopedia | wikimedia/wikipedia, config 20231101.en (use 20231101.simple for tests) | about 6.4M articles | CC BY-SA 3.0 / GFDL |
| Web and blogs | HuggingFaceFW/fineweb-edu, sample-10BT | about 10B tokens | ODC-By 1.0 |
| Books | sedthh/gutenberg_english | 48,284 books (about 10.7 GB) | Public domain in the US |
| Recipes | RecipeNLG (manual download) | 2,231,142 recipes | No known licence |

## Recipes (read this)
RecipeNLG has no known licence and cannot be fetched automatically.
1. Download it yourself from the RecipeNLG project page and read its terms.
2. Run with:  --recipes_csv full_dataset.csv --recipes 50000
Without the CSV, the recipe step is skipped. Do not publish a model or dataset built on it
until you have checked the terms. Use only recipes you have the right to use.

## Licence notes
- Wikipedia is share-alike: keep attribution (SOURCES.md and the title field help).
- FineWeb-Edu pages are web text; the dataset licence does not remove the original owners' rights.
- Gutenberg: US public domain only; the HF dataset's own card warns a few books may be copyrighted.
- This kit does not copy "every blog" or "every recipe": it uses these open collections only.

## Honest limits
- Download steps were NOT tested here (my environment cannot reach Hugging Face).
  The text-conversion code was tested on sample rows.
- Names of datasets/configs were confirmed from their dataset pages, but the sites can change.
- Large sizes need disk space: 50k Wikipedia + 50k web + 300 books is roughly 1-2 GB.
