"""Convert a .parquet dataset into small .jsonl files (about 20 MB each) for data/datasets/.
Usage:  python parquet_to_jsonl.py train-00000-of-00001.parquet
It prints the column names, picks the question/answer columns by name, and writes
<name>_part1.jsonl, <name>_part2.jsonl ...   Rows without both a question and an answer are skipped.
If the columns are not found, run it once, read the printed names, and set Q= and A= below.
"""
import sys, json, os
import pandas as pd

Q = None   # e.g. "instruction"  (leave None to auto-detect)
A = None   # e.g. "output"
MAX_BYTES = 20 * 1024 * 1024

src = sys.argv[1]
df = pd.read_parquet(src)
print("rows:", len(df)); print("columns:", list(df.columns))
cols = {c.lower(): c for c in df.columns}
def find(names): return next((cols[n] for n in names if n in cols), None)
q = Q or find(["instruction", "question", "prompt", "input", "query", "q"])
a = A or find(["response", "answer", "completion", "output", "reply", "a"])
if not q or not a:
    sys.exit("Could not find question/answer columns. Set Q= and A= at the top of this file.")
print(f"using question={q!r} answer={a!r}")

base = os.path.splitext(os.path.basename(src))[0]
part, size, out, kept = 1, 0, None, 0
def open_part():
    global out, size
    if out: out.close()
    out = open(f"{base}_part{part}.jsonl", "w", encoding="utf-8"); size = 0
open_part()
for _, r in df.iterrows():
    qq, aa = r[q], r[a]
    if not isinstance(qq, str) or not isinstance(aa, str) or not qq.strip() or not aa.strip(): continue
    line = json.dumps({"instruction": qq.strip(), "response": aa.strip()}, ensure_ascii=False) + "\n"
    if size + len(line.encode()) > MAX_BYTES: part += 1; open_part()
    out.write(line); size += len(line.encode()); kept += 1
out.close()
print(f"wrote {kept} rows into {part} file(s)")
