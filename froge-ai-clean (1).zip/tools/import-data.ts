/**
 * Import datasets (e.g. downloaded from Hugging Face) into data/datasets/ so the AI can use them.
 *
 *   npm run data:import -- path/to/train-00000-of-00001.parquet
 *   npm run data:import -- my.csv --name my_csv --max 100000
 *   npm run data:import -- some_folder/            (imports every .parquet .csv .json .jsonl inside)
 *
 * Options:  --name <prefix>   output file prefix (default: file name)
 *           --max <n>         keep at most n rows per input file (default 50000)
 *           --maxchars <n>    cut very long answers to n characters (default 4000)
 *           --maxq <n>        cut very long questions to n characters (default 1500)
 *           --mb <n>          size of each output part in MB (default 20)
 *           --out <dir>       output folder (default data/datasets)
 *
 * Also: .pdf (text PDFs), .txt and .md are cut into searchable text pieces.
 *   PDFs use the `pdftotext` program if it is installed (fast, good for huge files: install poppler),
 *   otherwise the built-in pdf.js reader (reads the whole file into memory). Scanned/image PDFs have no text (OCR first).
 *   Tip for big PDFs: add --max 500000 (the default keeps only 50000 pieces).
 *
 * Understands: question/answer, instruction(+input)/output, prompt/completion, query/response,
 * problem/solution/answer, reasoning/rationale/cot + answer, conversations/messages chat turns,
 * and plain {text} documents. Output is small .jsonl parts: {"instruction": ..., "response": ...}
 */
import fs from 'fs';
import path from 'path';
import readline from 'readline';
import { spawn, spawnSync } from 'child_process';
import { asyncBufferFromFile, parquetMetadataAsync, parquetReadObjects } from 'hyparquet';
import { compressors } from 'hyparquet-compressors';
import { pathToFileURL } from 'url';
import { normalizeRecord, type Raw } from '../src/brain/datasetAI';

export interface ImportOptions { name?: string; max: number; maxchars: number; maxq: number; mb: number; out: string; }
function args() {
  const a = process.argv.slice(2), o: Record<string, string> = {}, files: string[] = [];
  for (let i = 0; i < a.length; i++) { if (a[i].startsWith('--')) { o[a[i].slice(2)] = a[i + 1]; i++; } else files.push(a[i]); }
  const opt: ImportOptions = { name: o.name, max: Number(o.max) || 50000, maxchars: Number(o.maxchars) || 4000, maxq: Number(o.maxq) || 1500, mb: Number(o.mb) || 20, out: o.out || path.join('data', 'datasets') };
  return { files, opt };
}

/** Make parquet values JSON-safe (BigInt -> number, Date -> string, typed arrays -> arrays). */
function clean(v: any): any {
  if (typeof v === 'bigint') return Number(v);
  if (v instanceof Date) return v.toISOString();
  if (ArrayBuffer.isView(v)) return Array.from(v as any);
  if (Array.isArray(v)) return v.map(clean);
  if (v && typeof v === 'object') { const o: any = {}; for (const k of Object.keys(v)) o[k] = clean(v[k]); return o; }
  return v;
}

function parseCsv(text: string): Record<string, string>[] {
  const rows: string[][] = []; let row: string[] = [], cell = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += c; }
    else if (c === '"') q = true;
    else if (c === ',') { row.push(cell); cell = ''; }
    else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; row.push(cell); cell = ''; if (row.length > 1 || row[0] !== '') rows.push(row); row = []; }
    else cell += c;
  }
  if (cell || row.length) { row.push(cell); rows.push(row); }
  const head = rows.shift() || [];
  return rows.map(r => Object.fromEntries(head.map((h, i) => [h.trim(), r[i] ?? ''])));
}

/** Cut a stream of text into ~1200 character pieces, preferring paragraph / sentence ends. */
async function* chunkStream(parts: AsyncIterable<string>): AsyncGenerator<{ text: string }> {
  let buf = '';
  for await (const part of parts) {
    buf += part.replace(/\r/g, '').replace(/[ \t]+/g, ' ');
    while (buf.length >= 1500) {
      let cut = Math.max(buf.lastIndexOf('\n\n', 1300), buf.lastIndexOf('. ', 1300));
      cut = cut < 600 ? 1300 : cut + 1;
      const chunk = buf.slice(0, cut).trim(); buf = buf.slice(cut);
      if (chunk.length > 60) yield { text: chunk };
    }
  }
  if (buf.trim().length > 60) yield { text: buf.trim() };
}

async function* pdfPages(file: string): AsyncGenerator<string> {
  const engine = process.env.PDF_ENGINE || 'auto';
  const hasPoppler = engine !== 'pdfjs' && spawnSync('pdftotext', ['-v'], { stdio: 'ignore' }).error === undefined;
  if (hasPoppler) {
    console.log('  PDF reader: pdftotext');
    const child = spawn('pdftotext', ['-enc', 'UTF-8', file, '-'], { stdio: ['ignore', 'pipe', 'ignore'] });
    child.stdout.setEncoding('utf8');
    for await (const part of child.stdout) yield part as string;
    return;
  }
  console.log('  PDF reader: built-in pdf.js (loads the whole file into memory)');
  // @ts-ignore - pdfjs ships its own .mjs build without a matching types path
  const pdfjs: any = await import('pdfjs-dist/legacy/build/pdf.mjs');
  const raw = fs.readFileSync(file);
  const task = pdfjs.getDocument({ data: new Uint8Array(raw.buffer, raw.byteOffset, raw.length), useSystemFonts: true, disableFontFace: true, verbosity: 0 });
  const doc = await task.promise;
  for (let n = 1; n <= doc.numPages; n++) {
    const page = await doc.getPage(n);
    const tc = await page.getTextContent();
    let text = ''; for (const it of tc.items as any[]) text += (it.str ?? '') + (it.hasEOL ? '\n' : ' ');
    page.cleanup();
    if (n % 100 === 0) console.log(`  page ${n}/${doc.numPages}`);
    yield text + '\n\n';
  }
  try { await task.destroy?.(); } catch { /* ignore */ }
}

async function* records(file: string): AsyncGenerator<any> {
  const ext = path.extname(file).toLowerCase();
  if (ext === '.parquet') {
    const buf = await asyncBufferFromFile(file);
    const meta = await parquetMetadataAsync(buf);
    let start = 0;
    for (const rg of meta.row_groups) {                       // one row group at a time keeps memory low
      const end = start + Number(rg.num_rows);
      const rows = await parquetReadObjects({ file: buf, compressors, rowStart: start, rowEnd: end });
      for (const r of rows) yield clean(r);
      start = end;
    }
  } else if (ext === '.pdf') {
    yield* chunkStream(pdfPages(file));
  } else if (ext === '.txt' || ext === '.md') {
    yield* chunkStream(fs.createReadStream(file, { encoding: 'utf8' }) as AsyncIterable<string>);
  } else if (ext === '.jsonl') {
    const rl = readline.createInterface({ input: fs.createReadStream(file, 'utf8'), crlfDelay: Infinity });
    for await (const line of rl) { if (!line.trim()) continue; try { yield JSON.parse(line); } catch { /* skip */ } }
  } else if (ext === '.json') {
    const j = JSON.parse(fs.readFileSync(file, 'utf8'));
    const arr = Array.isArray(j) ? j : Array.isArray(j?.data) ? j.data : Array.isArray(j?.rows) ? j.rows.map((r: any) => r.row ?? r) : [j];
    for (const r of arr) yield r;
  } else if (ext === '.csv' || ext === '.tsv') {
    for (const r of parseCsv(fs.readFileSync(file, 'utf8'))) yield r;
  } else throw new Error(`Unsupported file type: ${ext}`);
}

export async function importFile(file: string, opt: ImportOptions, partOffset = 0) {
  const base = (opt.name || path.basename(file, path.extname(file))).replace(/[^\w.-]+/g, '_');
  fs.mkdirSync(opt.out, { recursive: true });
  let part = partOffset, bytes = 0, out: fs.WriteStream | null = null, read = 0, kept = 0, skipped = 0, cols: string[] = [];
  const write = (obj: object) => {
    const line = JSON.stringify(obj) + '\n', n = Buffer.byteLength(line);
    if (!out || bytes + n > opt.mb * 1024 * 1024) { out?.end(); part++; bytes = 0; out = fs.createWriteStream(path.join(opt.out, `${base}_part${part}.jsonl`)); }
    out.write(line); bytes += n;
  };
  for await (const rec of records(file)) {
    read++;
    if (read === 1 && rec && typeof rec === 'object') cols = Object.keys(rec);
    const items: Raw[] = normalizeRecord(rec, base);
    if (!items.length) { skipped++; continue; }
    for (const it of items) {
      if (kept >= opt.max) break;
      if (it.d) write({ text: it.a.slice(0, opt.maxchars) });
      else write({ instruction: it.q.slice(0, opt.maxq), response: it.a.slice(0, opt.maxchars) });
      kept++;
      if (kept % 20000 === 0) console.log(`  ... ${kept} rows`);
    }
    if (kept >= opt.max) break;
  }
  out?.end();
  console.log(`${path.basename(file)}: read ${read} rows, kept ${kept}, skipped ${skipped}, wrote ${part - partOffset} file(s) to ${opt.out}`);
  if (kept === 0) console.log(`  Could not find question/answer columns. Columns in this file: ${cols.join(', ') || '(none)'}`);
  return { kept, parts: part - partOffset };
}

async function main() {
  const { files, opt } = args();
  if (!files.length) { console.log('Usage: npm run data:import -- <file-or-folder> [--name x] [--max 50000] [--maxchars 4000] [--mb 20]'); process.exit(1); }
  const list: string[] = [];
  for (const f of files) {
    if (fs.statSync(f).isDirectory()) fs.readdirSync(f).filter(x => /\.(parquet|csv|tsv|json|jsonl|pdf|txt|md)$/i.test(x)).sort().forEach(x => list.push(path.join(f, x)));
    else list.push(f);
  }
  let total = 0;
  let off = 0;
  for (const f of list) { try { const r = await importFile(f, opt, off); total += r.kept; off += r.parts; } catch (e: any) { console.error(`${f}: ${e.message}`); } }
  console.log(`Done. ${total} rows imported. The AI picks them up automatically (no restart needed).`);
}
if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) main();
