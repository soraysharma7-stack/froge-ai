/**
 * Self-check tool: builds a question set (default 7000) with the correct answer under each question,
 * runs your AI on it, scores it, and can write everything as a PDF.   Nothing runs until YOU run it.
 *
 *   npm run eval:make                      -> data/eval/eval_7000.jsonl   (questions + expected answers)
 *   npm run eval:run                       -> asks the AI every question, prints the score, saves results
 *   npm run eval:pdf                       -> data/eval/eval_7000.pdf     (question, then the answer below it)
 *
 * Options:  --count 7000   --seed 1   --out data/eval   --limit 500 (run only the first 500)
 *           --engine app|dataset   app = the real engine (default), dataset = Dataset AI + calculator only
 *           --holdout    (run) remove the test questions from the AI's data first = honest "never seen it" test
 *           --results <file>  (pdf) add the AI's answers and PASS/FAIL to the PDF
 *
 * Question types:  dataset (re-worded questions from your files), math (computed answers),
 *                  followup (uses the previous chat), unknown (made-up topics: the AI should say it does not know)
 */
import fs from 'fs';
import path from 'path';
import PDFDocument from 'pdfkit';
import { DatasetAI, loadRawItems, normQ, tokenize, type ChatTurn } from '../src/brain/datasetAI';
import { solveMath } from '../src/brain/calcReasoner';

interface EvalItem { id: number; category: 'dataset' | 'math' | 'followup' | 'unknown'; question: string; expected: string; history?: ChatTurn[]; origQ?: string; source?: string; }
interface Result extends EvalItem { answer: string; pass: boolean; ms: number; }

function parse() {
  const a = process.argv.slice(2), cmd = a[0] || '', o: Record<string, string | boolean> = {};
  for (let i = 1; i < a.length; i++) { if (a[i] === '--holdout') o.holdout = true; else if (a[i].startsWith('--')) { o[a[i].slice(2)] = a[i + 1]; i++; } }
  const count = Number(o.count) || 7000, out = String(o.out || path.join('data', 'eval'));
  return { cmd, count, seed: Number(o.seed) || 1, out, limit: Number(o.limit) || 0, engine: String(o.engine || 'app'), holdout: Boolean(o.holdout),
    file: String(o.file || path.join(out, `eval_${count}.jsonl`)), results: String(o.results || ''), pdf: String(o.pdfout || path.join(out, `eval_${count}.pdf`)) };
}
function rng(seed: number) { let t = seed >>> 0; return () => { t += 0x6d2b79f5; let r = Math.imul(t ^ (t >>> 15), 1 | t); r ^= r + Math.imul(r ^ (r >>> 7), 61 | r); return ((r ^ (r >>> 14)) >>> 0) / 4294967296; }; }
const readJsonl = <T>(f: string): T[] => fs.readFileSync(f, 'utf8').split('\n').filter(Boolean).map(l => JSON.parse(l));
const ascii = (s: string) => s.replace(/[\u2018\u2019]/g, "'").replace(/[\u201c\u201d]/g, '"').replace(/[^\x20-\x7e\n]/g, '?');

// ---------------------------------------------------------------- make
function makeMath(r: () => number, n: number): EvalItem[] {
  const int = (lo: number, hi: number) => lo + Math.floor(r() * (hi - lo + 1)), out: EvalItem[] = [];
  for (let i = 0; i < n; i++) {
    let q = '', v = 0; const k = int(0, 9);
    const a = int(2, 99), b = int(2, 99), c = int(2, 20);
    if (k === 0) { q = `What is ${a} + ${b}?`; v = a + b; }
    else if (k === 1) { q = `What is ${a + b} - ${b}?`; v = a; }
    else if (k === 2) { q = `What is ${a} x ${b}?`; v = a * b; }
    else if (k === 3) { q = `What is ${a * c} divided by ${c}?`; v = a; }
    else if (k === 4) { q = `Calculate (${a} + ${b}) * ${c}`; v = (a + b) * c; }
    else if (k === 5) { q = `What is ${a} + ${b} * ${c}?`; v = a + b * c; }
    else if (k === 6) { const p = [5, 10, 20, 25, 50][int(0, 4)], x = int(1, 40) * 20; q = `What is ${p}% of ${x}?`; v = (x * p) / 100; }
    else if (k === 7) { q = `What is the square root of ${a * a}?`; v = a; }
    else if (k === 8) { const e = int(2, 8); q = `What is ${c}^${e}?`; v = Math.pow(c, e); }
    else { q = `What is ${a} plus ${b} times ${c}?`; v = a + b * c; }
    out.push({ id: 0, category: 'math', question: q, expected: String(v) });
  }
  return out;
}
function make(o: ReturnType<typeof parse>) {
  const r = rng(o.seed), dir = path.resolve(process.cwd(), 'data', 'datasets');
  const all = loadRawItems(dir), freq = new Map<string, number>();
  for (const x of all) freq.set(normQ(x.q), (freq.get(normQ(x.q)) || 0) + 1);
  const pool = all.filter(x => !x.d && x.q.length >= 12 && x.q.length <= 200 && x.a.length >= 3 && x.a.length <= 700 &&
    /^[\x20-\x7e\n\u2018\u2019\u201c\u201d]+$/.test(x.q + x.a) && freq.get(normQ(x.q)) === 1 && !/^what is [\d\s+x*\/().^%-]+\??$/i.test(x.q) && !/^(calculate|what is the square)/i.test(x.q));
  console.log(`Pool of usable questions in data/datasets: ${pool.length}`);
  const nMath = Math.round(o.count * 0.2), nUnk = Math.round(o.count * 0.05);
  const byQ = new Map(pool.map(x => [x.q, x] as const));
  const follow: EvalItem[] = [], want = Math.round(o.count * 0.1), usedByFollow = new Set<string>();
  for (const x of pool) {                                   // "symbol of X" then "and its atomic number?"
    const m = /^What is the symbol of (\w+)\?$/.exec(x.q); if (!m) continue;
    const z = byQ.get(`What is the atomic number of ${m[1]}?`); const num = z && /atomic number (\d+)/.exec(z.a)?.[1];
    if (num) usedByFollow.add(x.q), usedByFollow.add(z!.q);
    if (num) follow.push({ id: 0, category: 'followup', question: 'and its atomic number?', expected: num, origQ: x.q,
      history: [{ role: 'user', content: x.q }, { role: 'assistant', content: x.a }], source: x.file });
  }
  const pick = <T,>(arr: T[], n: number) => { const c = [...arr]; for (let i = c.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [c[i], c[j]] = [c[j], c[i]]; } return c.slice(0, n); };
  // spread the questions evenly over the data files (otherwise the 207k dictionary rows would dominate)
  const balanced = <T extends { file: string }>(arr: T[], n: number): T[] => {
    const g = new Map<string, T[]>(); arr.forEach(x => { if (!g.has(x.file)) g.set(x.file, []); g.get(x.file)!.push(x); });
    const lists = [...g.values()].map(l => pick(l, l.length)), res: T[] = [];
    for (let i = 0; res.length < n; i++) { let any = false; for (const l of lists) { if (i < l.length) { res.push(l[i]); any = true; if (res.length >= n) break; } } if (!any) break; }
    return res;
  };
  const items: EvalItem[] = [];
  items.push(...makeMath(r, nMath));
  const f = pick(follow, want); items.push(...f);
  for (let i = 0; i < nUnk; i++) items.push({ id: 0, category: 'unknown', question: `What is the ${['zorbloxian', 'fleebic', 'krandlish', 'quopsy'][i % 4]} theorem of planet ${['Xyzzy', 'Plugh', 'Qorvath'][i % 3]}-${1000 + i}?`, expected: "I don't have that in my dataset files" });
  const rest = o.count - items.length, pre = ['', 'can you tell me ', 'could you please tell me ', 'please tell me '];
  for (const x of balanced(pool.filter(p => !usedByFollow.has(p.q)), rest)) {
    const v = Math.floor(r() * 4); let q = x.q;
    if (v === 1) q = q.replace(/[?.!]+$/, '').toLowerCase(); else if (v >= 2) q = pre[v - 1] + q.replace(/[?.!]+$/, '').replace(/^./, c => c.toLowerCase());
    items.push({ id: 0, category: 'dataset', question: q, expected: x.a, origQ: x.q, source: x.file });
  }
  if (items.length < o.count) console.log(`Note: only ${items.length} questions could be made (the data folder is small). Add more data and run again.`);
  const final = pick(items, items.length).map((x, i) => ({ ...x, id: i + 1 }));
  fs.mkdirSync(o.out, { recursive: true });
  fs.writeFileSync(o.file, final.map(x => JSON.stringify(x)).join('\n') + '\n');
  const cnt: Record<string, number> = {}; final.forEach(x => (cnt[x.category] = (cnt[x.category] || 0) + 1));
  console.log(`Wrote ${final.length} questions to ${o.file}`, cnt);
}

// ---------------------------------------------------------------- run
const numIn = (s: string) => { const m = /Answer:\s*(-?[\d,]*\.?\d+)/i.exec(s); return m ? Number(m[1].replace(/,/g, '')) : NaN; };
function judge(it: EvalItem, ans: string): boolean {
  if (it.category === 'math') return Math.abs(numIn(ans) - Number(it.expected)) < 1e-6 * Math.max(1, Math.abs(Number(it.expected)));
  if (it.category === 'followup') return new RegExp(`\\b${it.expected}\\b`).test(ans);
  if (it.category === 'unknown') return /don't have that|do not have that/i.test(ans);
  const exp = new Set(tokenize(it.expected).slice(0, 300)), got = new Set(tokenize(ans));
  if (!exp.size) return ans.trim() === it.expected.trim();
  let hit = 0; exp.forEach(t => { if (got.has(t)) hit++; });
  return hit / exp.size >= 0.8;
}
async function run(o: ReturnType<typeof parse>) {
  if (!fs.existsSync(o.file)) { console.error(`No question file at ${o.file}. Run: npm run eval:make`); process.exit(1); }
  let items = readJsonl<EvalItem>(o.file); if (o.limit) items = items.slice(0, o.limit);
  process.env.DATASET_ONLY = 'true';
  let ask: (it: EvalItem) => string;
  if (o.engine === 'dataset' || o.holdout) {
    const ds = o.holdout ? new DatasetAI(undefined, new Set(items.filter(x => x.category === 'dataset' && x.origQ).map(x => normQ(x.origQ!)))) : new DatasetAI();
    ask = it => { const m = solveMath(it.question); if (m) return m.content; return ds.answer(it.question, it.history || [])?.content ?? "I don't have that in my dataset files yet."; };
    console.log(o.holdout ? 'Hold-out mode: the test questions were removed from the AI data first.' : 'Engine: Dataset AI + calculator');
  } else {
    const { frogeBrainEngine } = await import('../src/brain/engine/frogeBrainEngine');
    ask = it => frogeBrainEngine.generate({ prompt: it.question, mode: 'simple-chat', conversationHistory: it.history || [] } as any).content;
    console.log('Engine: the real app engine');
  }
  const res: Result[] = [], t0 = Date.now();
  for (const it of items) {
    const t = Date.now(); let ans = ''; try { ans = ask(it); } catch (e: any) { ans = `ERROR: ${e.message}`; }
    res.push({ ...it, answer: ans, pass: judge(it, ans), ms: Date.now() - t });
    if (res.length % 500 === 0) console.log(`  ${res.length}/${items.length}`);
  }
  const resFile = path.join(o.out, `results_${o.count}${o.holdout ? '_holdout' : ''}.jsonl`);
  fs.writeFileSync(resFile, res.map(x => JSON.stringify(x)).join('\n') + '\n');
  const by: Record<string, { n: number; ok: number }> = {};
  res.forEach(x => { const b = (by[x.category] ||= { n: 0, ok: 0 }); b.n++; if (x.pass) b.ok++; });
  const ok = res.filter(x => x.pass).length;
  console.log(`\nScore: ${ok}/${res.length} = ${((100 * ok) / Math.max(1, res.length)).toFixed(1)}%   (${((Date.now() - t0) / 1000).toFixed(1)} s)`);
  for (const [k, v] of Object.entries(by)) console.log(`  ${k.padEnd(9)} ${v.ok}/${v.n}  ${((100 * v.ok) / v.n).toFixed(1)}%`);
  const bad = res.filter(x => !x.pass).slice(0, 8);
  if (bad.length) { console.log('\nFirst wrong answers:'); bad.forEach(x => console.log(` #${x.id} [${x.category}] ${x.question}\n    expected: ${x.expected.slice(0, 90).replace(/\n/g, ' ')}\n    got:      ${x.answer.slice(0, 90).replace(/\n/g, ' ')}`)); }
  fs.writeFileSync(path.join(o.out, `summary_${o.count}${o.holdout ? '_holdout' : ''}.json`), JSON.stringify({ score: ok / Math.max(1, res.length), total: res.length, by }, null, 2));
  console.log(`\nResults saved: ${resFile}\nMake the PDF with answers: npm run eval:pdf -- --results ${resFile}`);
}

// ---------------------------------------------------------------- pdf
function pdf(o: ReturnType<typeof parse>) {
  if (!fs.existsSync(o.file)) { console.error(`No question file at ${o.file}. Run: npm run eval:make`); process.exit(1); }
  const items: Array<EvalItem & Partial<Result>> = o.results && fs.existsSync(o.results) ? readJsonl<Result>(o.results) : readJsonl<EvalItem>(o.file);
  const doc = new PDFDocument({ size: 'A4', margin: 40 });
  doc.pipe(fs.createWriteStream(o.pdf));
  doc.font('Helvetica-Bold').fontSize(20).text('AI Check: questions and answers', { align: 'left' });
  doc.font('Helvetica').fontSize(10).moveDown().text(`${items.length} questions. The correct answer is under each question${o.results ? '; then the AI answer and PASS / FAIL' : ''}.`);
  const pass = items.filter(x => x.pass).length; if (o.results) doc.text(`Score: ${pass}/${items.length}`);
  doc.addPage();
  for (const it of items) {
    if (doc.y > 740) doc.addPage();
    doc.font('Helvetica-Bold').fontSize(9).fillColor('#000').text(`Q${it.id} [${it.category}]  ${ascii(it.question)}`);
    doc.font('Helvetica').fontSize(8).fillColor('#14602b').text(`Correct answer: ${ascii(it.expected).slice(0, 600)}`);
    if (o.results && it.answer !== undefined) {
      doc.fillColor('#444').text(`AI answer: ${ascii(it.answer).slice(0, 400)}`);
      doc.font('Helvetica-Bold').fillColor(it.pass ? '#14602b' : '#b00020').text(it.pass ? 'PASS' : 'FAIL');
    }
    doc.moveDown(0.6);
  }
  doc.end();
  console.log(`PDF written: ${o.pdf}  (${items.length} questions)`);
}

const o = parse();
if (o.cmd === 'make') make(o); else if (o.cmd === 'run') run(o); else if (o.cmd === 'pdf') pdf(o);
else console.log('Usage: npm run eval:make | eval:run | eval:pdf   (see the top of tools/eval.ts for options)');
