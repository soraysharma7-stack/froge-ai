/**
 * Download datasets from Hugging Face and import them (run this on YOUR computer, with internet).
 *
 *   npm run data:fetch -- list                      show the ready-made datasets
 *   npm run data:fetch -- code_instructions         download + import one
 *   npm run data:fetch -- code_instructions magicoder_evol agentinstruct
 *   npm run data:fetch -- all
 *   npm run data:fetch -- --repo owner/name [--config main] [--limit-files 1] [--target datasets|training] [--max 50000]
 *
 * Options: --keep  keep the downloaded files in data/downloads (default: delete after import)
 * Env:     HF_TOKEN=hf_xxx   for gated/private datasets      HF_ENDPOINT=https://huggingface.co
 *
 * target "datasets" -> data/datasets  (the AI searches these files)
 * target "training" -> data/training  (for fine-tuning with training/train.py; not loaded by the AI)
 */
import fs from 'fs';
import path from 'path';
import { Readable } from 'stream';
import { pipeline } from 'stream/promises';
import { importFile, type ImportOptions } from './import-data';

interface Entry { repo: string; files?: string[]; auto?: boolean; config?: string; limitFiles?: number; what?: string; license?: string; approxDownloadMB?: number; target?: 'datasets' | 'training'; max?: number; maxchars?: number; maxq?: number; }
const HF = (process.env.HF_ENDPOINT || 'https://huggingface.co').replace(/\/$/, '');
const HF_DS_SERVER = (process.env.HF_DATASETS_SERVER || 'https://datasets-server.huggingface.co').replace(/\/$/, '');
const DATA = process.env.FROGE_DATA_DIR || 'data';
const TOKEN = process.env.HF_TOKEN;
const headers = (): Record<string, string> => (TOKEN ? { Authorization: `Bearer ${TOKEN}` } : {});

const manifest: Record<string, Entry> = JSON.parse(fs.readFileSync(new URL('./hf-datasets.json', import.meta.url), 'utf8'));

async function listParquetFiles(e: Entry): Promise<string[]> {
  // Hugging Face's own "parquet" API lists the parquet files of any dataset.
  const res = await fetch(`${HF_DS_SERVER}/parquet?dataset=${encodeURIComponent(e.repo)}`, { headers: headers() });
  if (!res.ok) throw new Error(`Could not list files for ${e.repo} (HTTP ${res.status}). Is the dataset public?`);
  const j: any = await res.json();
  let files: any[] = j.parquet_files || [];
  if (e.config) files = files.filter(f => f.config === e.config);
  const split = files.some(f => f.split === 'train') ? 'train' : files[0]?.split;
  files = files.filter(f => f.split === split).sort((a, b) => String(a.filename).localeCompare(String(b.filename)));
  if (e.limitFiles) files = files.slice(0, e.limitFiles);
  return files.map(f => f.url as string);
}

async function download(url: string, dest: string) {
  const res = await fetch(url, { headers: headers(), redirect: 'follow' });
  if (!res.ok || !res.body) throw new Error(`HTTP ${res.status} for ${url}`);
  const total = Number(res.headers.get('content-length')) || 0;
  if (fs.existsSync(dest) && total && fs.statSync(dest).size === total) { console.log(`  already downloaded: ${path.basename(dest)}`); return; }
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  try { const free = fs.statfsSync(path.dirname(dest)); if (total && free.bavail * free.bsize < total * 1.5) console.warn('  Warning: free disk space looks low for this file.'); } catch { /* ignore */ }
  let got = 0, lastPct = -1;
  const src = Readable.fromWeb(res.body as any);
  src.on('data', (c: Buffer) => { got += c.length; if (total) { const p = Math.floor((got / total) * 20) * 5; if (p !== lastPct) { lastPct = p; process.stdout.write(`\r  ${path.basename(dest)}: ${p}% (${(got / 1048576).toFixed(0)} MB)`); } } });
  await pipeline(src, fs.createWriteStream(dest));
  process.stdout.write('\n');
}

async function fetchEntry(key: string, e: Entry, keep: boolean) {
  console.log(`\n== ${key}: ${e.repo}${e.what ? '\n   ' + e.what : ''}\n   License: ${e.license || 'see the dataset page'}`);
  const urls = e.files && !e.auto ? e.files.map(f => `${HF}/datasets/${e.repo}/resolve/main/${f}`) : await listParquetFiles(e);
  if (!urls.length) throw new Error('No files found.');
  const target = e.target || 'datasets';
  const out = path.join(DATA, target);
  const opt: ImportOptions = { max: e.max || 50000, maxchars: e.maxchars || 4000, maxq: e.maxq || 1500, mb: 20, out };
  let total = 0;
  for (const url of urls) {
    const base = decodeURIComponent(path.basename(new URL(url).pathname));
    const dest = path.join(DATA, 'downloads', key, base);
    await download(url, dest);
    const stem = base.replace(/\.[^.]+$/, '').replace(/[^\w]+/g, '_').slice(0, 30);
    const r = await importFile(dest, { ...opt, name: `${key}_${stem}` });
    total += r.kept;
    if (!keep) fs.rmSync(dest, { force: true });
  }
  console.log(`   -> ${total} rows imported into ${out}${target === 'training' ? '  (training data: use training/train.py)' : ''}`);
}

async function main() {
  const a = process.argv.slice(2), flags: Record<string, string | boolean> = {}, keys: string[] = [];
  for (let i = 0; i < a.length; i++) {
    if (a[i] === '--keep') flags.keep = true;
    else if (a[i].startsWith('--')) { flags[a[i].slice(2)] = a[i + 1]; i++; }
    else keys.push(a[i]);
  }
  if (keys[0] === 'list' || (!keys.length && !flags.repo)) {
    console.log('Ready-made datasets (npm run data:fetch -- <name>):\n');
    for (const [k, e] of Object.entries(manifest)) console.log(`${k.padEnd(18)} ~${String(e.approxDownloadMB).padStart(4)} MB  -> ${(e.target || 'datasets').padEnd(8)} ${e.repo}\n${' '.repeat(18)} ${e.what}\n${' '.repeat(18)} License: ${e.license}\n`);
    return;
  }
  const todo: Array<[string, Entry]> = [];
  if (flags.repo) todo.push([String(flags.repo).split('/').pop()!.replace(/[^\w]+/g, '_'), {
    repo: String(flags.repo), auto: true, config: flags.config as string | undefined, limitFiles: Number(flags['limit-files']) || 1,
    target: (flags.target as 'datasets' | 'training') || 'datasets', max: Number(flags.max) || 50000, maxchars: Number(flags.maxchars) || 4000 }]);
  for (const k of keys[0] === 'all' ? Object.keys(manifest) : keys) { if (!manifest[k]) { console.error(`Unknown dataset "${k}". Run: npm run data:fetch -- list`); process.exit(1); } todo.push([k, manifest[k]]); }
  for (const [k, e] of todo) { try { await fetchEntry(k, e, Boolean(flags.keep)); } catch (err: any) { console.error(`  ${k} failed: ${err.message}`); } }
  console.log('\nDone. Files in data/datasets are picked up automatically (no restart). Check each licence before sharing or selling a model.');
}
main();
