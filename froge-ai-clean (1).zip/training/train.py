"""Fine-tune a small open model on chat_instructions.jsonl with LoRA.
Usage:
  python training/train.py --data data/datasets/chat_instructions.jsonl
  python train.py --model Qwen/Qwen2.5-1.5B-Instruct --samples 20000 --epochs 2
Extra data (your own, same format {"instruction":..,"response":..}):
  python train.py --extra my_data.jsonl
"""
import argparse, json, random, torch
from transformers import (AutoTokenizer, AutoModelForCausalLM, Trainer,
                          TrainingArguments, DataCollatorForSeq2Seq)
from peft import LoraConfig, get_peft_model

ap = argparse.ArgumentParser()
ap.add_argument("--model", default="Qwen/Qwen2.5-0.5B-Instruct")
ap.add_argument("--data", default="data/datasets/chat_instructions.jsonl")
ap.add_argument("--extra", nargs="*", default=[])
ap.add_argument("--samples", type=int, default=15000)
ap.add_argument("--epochs", type=float, default=2)
ap.add_argument("--max_len", type=int, default=512)
ap.add_argument("--batch", type=int, default=4)
ap.add_argument("--lr", type=float, default=2e-4)
ap.add_argument("--out", default="my_ai")
a = ap.parse_args()
random.seed(1)

rows = []
for f in [a.data] + a.extra:
    rows += [json.loads(l) for l in open(f, encoding="utf-8")]
random.shuffle(rows)
rows = rows[:a.samples]
val, train = rows[:300], rows[300:]
print(f"train={len(train)} val={len(val)}")

tok = AutoTokenizer.from_pretrained(a.model)
if tok.pad_token is None: tok.pad_token = tok.eos_token
cuda = torch.cuda.is_available()
dtype = torch.bfloat16 if cuda and torch.cuda.is_bf16_supported() else (torch.float16 if cuda else torch.float32)
model = AutoModelForCausalLM.from_pretrained(a.model, torch_dtype=dtype)
model = get_peft_model(model, LoraConfig(r=16, lora_alpha=32, lora_dropout=0.05,
                       target_modules="all-linear", task_type="CAUSAL_LM"))
model.print_trainable_parameters()

def encode(r):
    msgs = [{"role": "user", "content": r["instruction"]}]
    prompt = tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True)
    p = tok(prompt, add_special_tokens=False)["input_ids"]
    x = tok(r["response"] + (tok.eos_token or ""), add_special_tokens=False)["input_ids"]
    ids = (p + x)[:a.max_len]
    labels = ([-100] * len(p) + x)[:a.max_len]   # learn only from the answer
    return {"input_ids": ids, "attention_mask": [1] * len(ids), "labels": labels}

class DS(torch.utils.data.Dataset):
    def __init__(s, r): s.d = [encode(x) for x in r]
    def __len__(s): return len(s.d)
    def __getitem__(s, i): return s.d[i]

args = TrainingArguments(
    output_dir=a.out + "_ckpt", num_train_epochs=a.epochs,
    per_device_train_batch_size=a.batch, gradient_accumulation_steps=4,
    learning_rate=a.lr, lr_scheduler_type="cosine", warmup_ratio=0.03,
    logging_steps=20, save_strategy="no", eval_strategy="epoch",
    bf16=(dtype == torch.bfloat16), fp16=(dtype == torch.float16),
    report_to="none", use_cpu=not cuda)
Trainer(model=model, args=args, train_dataset=DS(train), eval_dataset=DS(val),
        data_collator=DataCollatorForSeq2Seq(tok, padding=True, label_pad_token_id=-100)).train()

model = model.merge_and_unload()
model.save_pretrained(a.out); tok.save_pretrained(a.out)
print("saved to", a.out)
for q in ["What does 'bifurcate' mean?", "What is 47 x 23?", "Is this review positive or negative? The film was a delight."]:
    t = tok.apply_chat_template([{"role": "user", "content": q}], tokenize=False, add_generation_prompt=True)
    ids = tok(t, return_tensors="pt", add_special_tokens=False).to(model.device)
    o = model.generate(**ids, max_new_tokens=80, do_sample=False)
    print("\nQ:", q, "\nA:", tok.decode(o[0][ids["input_ids"].shape[1]:], skip_special_tokens=True))
