"""Chat with your trained model:  python chat.py my_ai"""
import sys, torch
from transformers import AutoTokenizer, AutoModelForCausalLM
p = sys.argv[1] if len(sys.argv) > 1 else "my_ai"
tok = AutoTokenizer.from_pretrained(p); m = AutoModelForCausalLM.from_pretrained(p, torch_dtype="auto")
hist = []
while True:
    q = input("You: ")
    if q.strip() in ("exit", "quit"): break
    hist.append({"role": "user", "content": q})
    t = tok.apply_chat_template(hist, tokenize=False, add_generation_prompt=True)
    ids = tok(t, return_tensors="pt", add_special_tokens=False)
    o = m.generate(**ids, max_new_tokens=200, do_sample=True, temperature=0.7, top_p=0.9)
    a = tok.decode(o[0][ids["input_ids"].shape[1]:], skip_special_tokens=True)
    print("AI:", a); hist.append({"role": "assistant", "content": a})
