# Training (fine-tuning a small model on your data)

Needs a GPU for speed. Your 4 GB / no-GPU computer is too slow: use free Google Colab or Kaggle.

1. Zip the app's `data/datasets` and `data/training` folders and upload them with `training/`.
2. `pip install -r training/requirements.txt`
3. Quick test:  `python training/train.py --samples 2000`
4. Real run (reasoning + code + agents), long examples need a longer window:
   `python training/train.py --model Qwen/Qwen2.5-1.5B-Instruct --samples 30000 --max_len 1024 --extra data/training/*.jsonl`
5. Download the `my_ai` folder, run it with Ollama / llama.cpp, then in the app's `.env` set
   FROGE_MODEL_ENDPOINT=http://127.0.0.1:11434/v1 and FROGE_MODEL=<your model name>.

Data format: one JSON per line: {"instruction": "...", "response": "..."} (the importer writes exactly this).
Not tested end-to-end here (no GPU or model downloads in my environment).
