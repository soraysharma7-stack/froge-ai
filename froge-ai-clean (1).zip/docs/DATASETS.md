# Datasets guide

Everything below runs on YOUR computer (it needs internet to download). Nothing is downloaded automatically.

## 1. Ready-made downloads  (`npm run data:fetch -- list`)

| Name | Dataset (Hugging Face) | Download | Licence | Goes to |
|---|---|---|---|---|
| `code_instructions` | iamtarun/code_instructions_120k_alpaca (121,959 rows) | ~72 MB | not stated on the card (derived from sahil2801/code_instructions_120k) - check | data/datasets |
| `magicoder_evol` | ise-uiuc/Magicoder-Evol-Instruct-110K (~110k rows) | ~255 MB | Apache-2.0 (card); redistributed from evol-codealpaca-v1 - check upstream | data/datasets |
| `agentinstruct` | microsoft/orca-agentinstruct-1M-v1: tool_use + webagent_flow + fs_cot_flow splits | ~210 MB | CDLA-Permissive-2.0; card says not for education or health systems | data/training |
| `gsm8k` | openai/gsm8k (7,473 maths problems) | ~1 MB | MIT | data/datasets |
| `bespoke_stratos` | bespokelabs/Bespoke-Stratos-17k (R1 reasoning traces) | ~100 MB | Apache-2.0 | data/training |
| `openr1_math` | open-r1/OpenR1-Math-220k (first parquet file only) | ~500 MB | Apache-2.0 | data/training |

Notes
- The complete AgentInstruct dataset is about 1 million pairs / 2.38 GB (the original ~25M-pair set is not public). Only the agent-related splits are fetched here.
- Sizes of gsm8k / bespoke_stratos / openr1_math are rough; their file lists are found at run time with Hugging Face's parquet API.
- Examples: `npm run data:fetch -- code_instructions magicoder_evol`   or   `npm run data:fetch -- all`
- Any other dataset: `npm run data:fetch -- --repo owner/name --limit-files 1 --max 50000`
- Files you downloaded by hand (parquet, csv, json, jsonl): `npm run data:import -- path/to/file.parquet`
  (folders work too). Add `--max 100000` to import more rows.

"datasets" files are searched by the AI. "training" files are only for fine-tuning (long agent and reasoning
traces are too big to search): `python training/train.py --extra data/training/*.jsonl`.

## 1b. Your own files: PDF, text, CSV, parquet, JSON
    npm run data:import -- book.pdf --max 500000     (text PDFs; install poppler for huge PDFs - much faster, less memory)
    npm run data:import -- notes.txt
    npm run data:import -- train.parquet
Scanned (picture-only) PDFs have no text; run OCR first. Or simply copy a .txt / .md / .jsonl file into data/datasets.
The AI memory limit is about 600,000 pieces (DATASET_MAX_ITEMS); a 0.5 GB PDF may be more, so import it in parts or raise the limit if you have RAM.

## 2. The ~0.5 GB text corpus (encyclopedia + web + books + recipes)
    pip install datasets
    python tools/corpus/build_corpus.py --test --to-datasets
    python tools/corpus/build_corpus.py --wiki 50000 --web 50000 --books 300 --to-datasets
See tools/corpus/README.md (licences, RecipeNLG manual download). `--to-datasets` copies the Q&A part into
data/datasets; the raw corpus.jsonl stays in data/corpus for training.

## 3. Complex reasoning - the honest picture
- The built-in AI **finds answers that are in its files** and has a **step-by-step calculator**. It does not reason
  about new problems.
- Real reasoning needs a trained model. Plan: import reasoning data (gsm8k, bespoke_stratos, openr1_math,
  agentinstruct) -> fine-tune a small model with `training/train.py` on Colab/Kaggle (free GPU) -> run it with
  Ollama -> set FROGE_MODEL_ENDPOINT in .env (see the main README).
- Check progress with the self-check tool below, using `--holdout`.

## 4. Self-check (7000 questions) - ready, not run
    npm run eval:make                      # data/eval/eval_7000.jsonl  (questions + correct answers)
    npm run eval:run                       # score; add -- --holdout for the honest "never seen it" test
    npm run eval:pdf -- --results data/eval/results_7000.jsonl     # PDF: each question, answer below it
Question types: dataset (re-worded), math (computed), followup (uses previous chat), unknown (AI must say it does not know).
Tested here with the starter data (7000 questions): 97.4% when the answers are in the data files. With `--holdout`
(the test questions removed from the data first) the dataset-type questions drop to about 9.5%, while maths (the calculator),
follow-ups and "I don't know" answers stay 100%. That low number is the limit of a search-based AI; only a trained model
(section 3) can answer questions it has not seen.
