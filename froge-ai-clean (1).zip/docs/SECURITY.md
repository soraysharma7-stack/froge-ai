# Security notes

## Community / Firestore (important if real people will use the app)
- The community uses a **fake local identity** (a random id kept in the browser), not Firebase login.
  So the rules in `firestore.rules` must stay open, and anyone can edit or delete other people's posts and profiles.
- A tight version is ready: `firestore.rules.secure` (author-only edit/delete, validated data).
  It was **not tested** (no Firebase emulator here) and it breaks the community until these steps are done:
  1. In the Firebase console turn on Authentication > Sign-in method > Anonymous.
  2. In the app call `signInAnonymously(auth)` at start and use `auth.currentUser.uid` as the profile `uid`
     (src/community/services/authService.ts) and as every post/comment `authorId`.
  3. Paste `firestore.rules.secure` into Firestore > Rules and test it in the Rules Playground.
- Until then: use the app for yourself only; do not put private data in the community.

## Keys
- `firebase-applet-config.json` holds a Firebase web key. Such keys are public by design; the rules are what protect the data.
- Never put model API keys (FROGE_MODEL_API_KEY) in the browser code; they stay in `.env` on the server. `.env` is in .gitignore.
