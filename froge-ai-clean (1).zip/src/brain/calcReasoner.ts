/**
 * Step-by-step calculator (no model, no eval). Handles:
 *   47 x 23,  (12 + 3) * 4 - 5,  2^10,  17 % 5,  20% of 150,  sqrt(144),  square root of 81,
 *   "what is 15 plus 7 times 2", "calculate 100 divided by 8".
 * Returns null when the text is not a pure maths question, so other answers can run.
 */
type Node = { op: 'num'; v: number } | { op: string; l: Node; r?: Node };

const WORD_OPS: Array<[RegExp, string]> = [
  [/\bmultiplied by\b|\btimes\b/g, '*'], [/\bdivided by\b|\bover\b/g, '/'], [/\bplus\b|\badd(ed to)?\b/g, '+'],
  [/\bminus\b|\bsubtract(ed by)?\b/g, '-'], [/\bto the power of\b|\bpower\b/g, '^'], [/\bmodulo\b|\bmod\b/g, '%'],
];

function fmt(n: number): string {
  if (!Number.isFinite(n)) return String(n);
  if (Number.isInteger(n) && Math.abs(n) < 1e15) return n.toLocaleString('en-US');
  return String(Number(n.toPrecision(12)));
}

function parse(src: string): Node | null {
  let i = 0;
  const ws = () => { while (src[i] === ' ') i++; };
  const num = (): Node | null => {
    ws();
    if (src.startsWith('sqrt', i)) {                       // sqrt(x)
      i += 4; ws(); if (src[i] !== '(') return null; i++;
      const e = expr(); ws(); if (!e || src[i] !== ')') return null; i++;
      return { op: 'sqrt', l: e };
    }
    if (src[i] === '(') { i++; const e = expr(); ws(); if (!e || src[i] !== ')') return null; i++; return e; }
    if (src[i] === '-') { i++; const x = power(); return x ? { op: 'neg', l: x } : null; }
    const m = /^\d+(\.\d+)?/.exec(src.slice(i)); if (!m) return null;
    i += m[0].length; ws();
    if (src[i] === '%' && !/^%\s*[\d(]/.test(src.slice(i))) { i++; return { op: '/', l: { op: 'num', v: Number(m[0]) }, r: { op: 'num', v: 100 } }; } // 20% -> 0.2
    return { op: 'num', v: Number(m[0]) };
  };
  const power = (): Node | null => {
    let l = num(); if (!l) return null; ws();
    if (src[i] === '^') { i++; const r = power(); if (!r) return null; l = { op: '^', l, r }; }
    return l;
  };
  const term = (): Node | null => {
    let l = power(); if (!l) return null;
    for (;;) { ws(); const c = src[i]; if (c === '*' || c === '/' || c === '%') { i++; const r = power(); if (!r) return null; l = { op: c, l, r }; } else return l; }
  };
  const expr = (): Node | null => {
    let l = term(); if (!l) return null;
    for (;;) { ws(); const c = src[i]; if (c === '+' || c === '-') { i++; const r = term(); if (!r) return null; l = { op: c, l, r }; } else return l; }
  };
  const e = expr(); ws();
  return e && i === src.length ? e : null;
}

function evaluate(n: Node, steps: string[]): number {
  if (n.op === 'num') return (n as { v: number }).v;
  const t = n as { op: string; l: Node; r?: Node };
  const a = evaluate(t.l, steps);
  if (t.op === 'neg') return -a;
  if (t.op === 'sqrt') { const v = Math.sqrt(a); steps.push(`sqrt(${fmt(a)}) = ${fmt(v)}`); return v; }
  const b = evaluate(t.r!, steps);
  let v: number;
  switch (t.op) {
    case '+': v = a + b; break; case '-': v = a - b; break; case '*': v = a * b; break;
    case '/': if (b === 0) throw new Error('Division by zero is undefined.'); v = a / b; break;
    case '%': if (b === 0) throw new Error('Remainder by zero is undefined.'); v = a % b; break;
    case '^': v = Math.pow(a, b); break; default: throw new Error('bad op');
  }
  const sym = t.op === '*' ? 'x' : t.op === '/' ? '÷' : t.op === '%' ? 'mod' : t.op;
  steps.push(`${fmt(a)} ${sym} ${fmt(b)} = ${fmt(v)}`);
  return v;
}

export function solveMath(raw: string): { content: string; answer: number } | null {
  let s = raw.toLowerCase().trim();
  s = s.replace(/[?=]+\s*$/g, '').replace(/,(?=\d{3})/g, '');                 // 1,000 -> 1000
  s = s.replace(/^(what('| i)?s|what is|calculate|compute|solve|find|evaluate|simplify|tell me|how much is|answer)\b[:\s]*/g, '')
       .replace(/^(the (value|result) of|the answer to)\s+/g, '').replace(/^the\s+/, '');
  let m = /^(\d+(?:\.\d+)?)\s*%\s*of\s*(\d+(?:\.\d+)?)$/.exec(s);             // 20% of 150
  if (m) s = `${m[2]} * ${m[1]} / 100`;
  s = s.replace(/square root of\s*(\d+(?:\.\d+)?)/g, 'sqrt($1)').replace(/\bsquare of\s*(\d+(?:\.\d+)?)/g, '$1^2');
  for (const [re, sym] of WORD_OPS) s = s.replace(re, ` ${sym} `);
  s = s.replace(/[×·]/g, '*').replace(/÷/g, '/').replace(/\*\*/g, '^').replace(/(\d)\s*x\s*(?=[\d(])/g, '$1 * ');
  s = s.replace(/\s+/g, ' ').trim();
  if (!/^[\d\s+\-*/().%^sqrt]+$/.test(s) || !/\d/.test(s)) return null;        // only maths characters allowed
  if (!/[+\-*/^%]|sqrt/.test(s.replace(/^-/, ''))) return null;                // must contain an operation
  const tree = parse(s); if (!tree) return null;
  const steps: string[] = [];
  try {
    const v = evaluate(tree, steps);
    const body = steps.length > 1 ? `Step by step:\n${steps.map((x, k) => `${k + 1}. ${x}`).join('\n')}\n\n` : '';
    return { content: `${body}Answer: ${fmt(v)}`, answer: v };
  } catch (e: any) { return { content: e.message, answer: NaN }; }
}
