/**
 * Dataset AI v2 - answers ONLY from files you put in  data/datasets/  (sub-folders too).
 * No model, no GPU, no internet. Drop a file in the folder, it is picked up automatically.
 *
 * Understands many Hugging Face style layouts:
 *   question/answer, instruction(+input)/response|output, prompt/completion, query/response,
 *   problem/solution(+answer), reasoning|rationale|cot|thinking + answer,
 *   conversations / messages (chat turns), and plain {text} documents (long text is chunked).
 * File types: .jsonl .json .txt .md  (use  npm run data:import  for .parquet and .csv)
 *
 * It remembers the previous chat: a follow-up like "and its atomic number?" is combined
 * with the previous question before searching.
 */
import fs from 'fs';
import path from 'path';

export interface Raw { q: string; a: string; file: string; d?: boolean; }
interface Item { a: string; file: string; d?: boolean; }
// Inverted index: term -> flat list [docId, tf, docId, tf, ...]  (small and fast; only scores docs that share a word)
interface Index { items: Item[]; post: Map<string, number[]>; len: Uint16Array; qh: Int32Array; avg: number; files: Record<string, number>; capped: boolean; }
export type ChatTurn = { role: string; content: string };

const Q_KEYS = ['instruction', 'question', 'prompt', 'query', 'problem', 'input', 'q', 'user', 'human'];
const A_KEYS = ['response', 'answer', 'completion', 'output', 'solution', 'a', 'reply', 'assistant', 'gpt', 'chosen'];
const R_KEYS = ['reasoning', 'rationale', 'cot', 'thinking', 'chain_of_thought', 'reasoning_content', 'explanation'];
const MAX_ANSWER_CHARS = 8000;
const CHUNK_CHARS = 1200;
const STOP = new Set('a an the is are was were be been am do does did of to in on at for and or it its this that these those i you he she we they me my your what who whom how why when where which can could would should please tell give about with from as by not no yes if then than so'.split(' '));

export function tokenize(s: string): string[] {
  return (s.toLowerCase().match(/[a-z0-9\u00c0-\u024f\u0900-\u0963\u0966-\u097f]+/g) || [])
    .map(w => w.length > 4 ? w.replace(/(ing|ed|es|s)$/, '') : w)
    .filter(w => (w.length > 1 || /\d/.test(w)) && !STOP.has(w));   // keep single digits: '7' matters
}
function hash(s: string): number { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h | 0; }
export const normQ = (s: string) => s.toLowerCase().replace(/[^a-z0-9\u0900-\u0963\u0966-\u097f]+/g, ' ').trim();

function str(x: any): string {
  if (typeof x === 'string') return x.trim();
  if (x && typeof x === 'object' && typeof x.text === 'string') return x.text.trim();
  return '';
}
function pick(o: any, keys: string[]): string {
  for (const k of keys) { const v = str(o?.[k]); if (v) return v; }
  return '';
}
function chunkText(text: string, size = CHUNK_CHARS): string[] {
  if (text.length <= size * 1.3) return [text];
  const out: string[] = []; let cur = '';
  for (const p of text.split(/\n\s*\n|(?<=[.!?])\s+(?=[A-Z])/)) {
    if (cur && cur.length + p.length > size) { out.push(cur.trim()); cur = ''; }
    cur += p + ' ';
  }
  if (cur.trim().length > 60) out.push(cur.trim());
  return out;
}

/** Turn any supported record into question/answer pairs (or document chunks). */
export function normalizeRecord(o: any, file = ''): Raw[] {
  const out: Raw[] = [];
  if (!o || typeof o !== 'object') return out;
  // chat formats
  const turns = Array.isArray(o.conversations) ? o.conversations : Array.isArray(o.messages) ? o.messages : null;
  if (turns) {
    let user = '';
    for (const t of turns) {
      const role = String(t.role ?? t.from ?? '').toLowerCase(), text = str(t.content ?? t.value ?? t.text);
      if (!text) continue;
      if (role === 'user' || role === 'human') user = text;
      else if ((role === 'assistant' || role === 'gpt' || role === 'bot') && user) { out.push({ q: user, a: text.slice(0, MAX_ANSWER_CHARS), file }); user = ''; }
    }
    return out;
  }
  let q = pick(o, Q_KEYS);
  const extra = str(o.input);
  if (q && extra && q !== extra && o.instruction) q = `${q} ${extra}`;        // Alpaca: instruction + input
  let a = pick(o, A_KEYS);
  const why = pick(o, R_KEYS);
  if (q && a) {
    if (why && !a.includes(why.slice(0, 40))) a = `${why}\n\nAnswer: ${a}`;
    else if (o.solution && o.answer && typeof o.answer !== 'object' && str(o.answer) && !a.includes(str(o.answer))) a = `${a}\n\nAnswer: ${str(o.answer)}`;
    out.push({ q, a: a.slice(0, MAX_ANSWER_CHARS), file });
  } else if (typeof o.word === 'string' && typeof o.definition === 'string') {  // dictionary rows
    const syn = Array.isArray(o.synonyms) && o.synonyms.length ? ` Synonyms: ${o.synonyms.slice(0, 6).join(', ')}.` : '';
    const ex = Array.isArray(o.examples) && o.examples.length ? ` Example: ${o.examples[0]}.` : '';
    out.push({ q: `${o.word} meaning definition synonyms`, a: `${o.word} (${o.pos || 'word'}): ${o.definition}.${syn}${ex}`, file });
  } else if (typeof o.text === 'string' && o.text.length > 40) {                  // plain documents
    const title = typeof o.title === 'string' ? o.title : '';
    for (const c of chunkText(o.text)) out.push({ q: title ? `${title} ${c}` : c, a: c, file, d: true });
  }
  return out;
}

function walk(dir: string, acc: string[] = []): string[] {
  if (!fs.existsSync(dir)) return acc;
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, acc); else acc.push(p);
  }
  return acc;
}
function loadFile(fp: string, out: Raw[], rel: string, cap: number) {
  const ext = path.extname(fp).toLowerCase();
  if (!['.jsonl', '.json', '.txt', '.md'].includes(ext)) return;
  if (path.basename(fp) === 'datasets_meta.json') return;
  const raw = fs.readFileSync(fp, 'utf8');
  const push = (rows: Raw[]) => { for (const r of rows) { if (out.length >= cap) return; out.push(r); } };
  if (ext === '.jsonl') {
    for (const line of raw.split('\n')) { if (out.length >= cap) return; if (!line.trim()) continue; try { push(normalizeRecord(JSON.parse(line), rel)); } catch { /* skip bad line */ } }
  } else if (ext === '.json') {
    try { const j = JSON.parse(raw); (Array.isArray(j) ? j : [j]).forEach(o => push(normalizeRecord(o, rel))); } catch { /* skip */ }
  } else {
    for (const p of raw.split(/\n\s*\n/)) if (p.trim().length > 60) push([{ q: p.trim(), a: p.trim(), file: rel, d: true }]);
  }
}
/** All raw items in the folder (used by the eval tool). */
export function loadRawItems(dir = path.resolve(process.cwd(), 'data', 'datasets'), cap = Number.MAX_SAFE_INTEGER): Raw[] {
  const out: Raw[] = [];
  for (const fp of walk(dir)) { try { loadFile(fp, out, path.relative(dir, fp), cap); } catch { /* skip */ } }
  return out;
}

/** Position of doc `id` in a posting list [id, tf, id, tf, ...] (sorted by id), or -1. */
function findPost(l: number[], id: number): number {
  let lo = 0, hi = l.length / 2 - 1;
  while (lo <= hi) { const mid = (lo + hi) >> 1, v = l[mid * 2]; if (v === id) return mid * 2; if (v < id) lo = mid + 1; else hi = mid - 1; }
  return -1;
}
const FOLLOW = /\b(it|its|that|this|those|these|they|them|their|he|she|his|her|him|there)\b/i;
const STARTS = /^\s*(and|also|then|but|so|why|how|what about|how about|more|explain|elaborate|continue)\b/i;

export class DatasetAI {
  private index: Index | null = null;
  private signature = '';
  constructor(
    private dir = path.resolve(process.cwd(), 'data', 'datasets'),
    private exclude: Set<string> | null = null,        // normalized questions to leave out (hold-out testing)
    private cap = Number(process.env.DATASET_MAX_ITEMS) || 600000,
  ) {}

  private sig(): string {
    return walk(this.dir).sort().map(f => { const s = fs.statSync(f); return `${f}:${s.size}:${s.mtimeMs}`; }).join('|') || 'none';
  }
  /** Rebuilds automatically when files are added/changed/removed. */
  private ensure() {
    const sig = this.sig();
    if (this.index && sig === this.signature) return;
    let raw = loadRawItems(this.dir, this.cap + 1);
    const capped = raw.length > this.cap; if (capped) raw = raw.slice(0, this.cap);
    if (this.exclude) raw = raw.filter(r => !this.exclude!.has(normQ(r.q)));
    const post = new Map<string, number[]>(), len = new Uint16Array(raw.length), qh = new Int32Array(raw.length), items: Item[] = [], files: Record<string, number> = {};
    let total = 0;
    raw.forEach((it, id) => {
      items.push({ a: it.a, file: it.file, d: it.d }); files[it.file] = (files[it.file] || 0) + 1;
      const toks = tokenize(it.q), m = new Map<string, number>();
      toks.forEach(t => m.set(t, (m.get(t) || 0) + 1));
      m.forEach((f, t) => { let l = post.get(t); if (!l) post.set(t, (l = [])); l.push(id, f); });
      len[id] = Math.min(toks.length, 65535); qh[id] = hash(normQ(it.q)); total += toks.length;
    });
    this.index = { items, post, len, qh, avg: total / Math.max(1, raw.length), files, capped };
    this.signature = sig;
    if (capped) console.warn(`[DatasetAI] Loaded only the first ${this.cap} items (set DATASET_MAX_ITEMS to change).`);
  }
  public size(): number { this.ensure(); return this.index!.items.length; }
  public info() { this.ensure(); return { items: this.index!.items.length, files: this.index!.files, capped: this.index!.capped }; }

  /** Best answer from the dataset, or null. Pass the chat history so follow-up questions work. */
  public answer(query: string, history: ChatTurn[] = []): { content: string; file: string; confidence: number; usedHistory?: boolean } | null {
    const q = (query || '').trim(); if (!q) return null;
    const prev = [...history].reverse().find(t => t.role === 'user' && t.content && normQ(t.content) !== normQ(q))?.content;
    const followUp = !!prev && (tokenize(q).length <= 2 || FOLLOW.test(q) || STARTS.test(q));
    if (followUp) { const r = this.search(`${prev} ${q}`, new Set(tokenize(q))); if (r) return { ...r, usedHistory: true }; }
    return this.search(q);
  }

  /** current = words of the user's newest message; they count double when the old question is added for a follow-up. */
  private search(query: string, current?: Set<string>): { content: string; file: string; confidence: number } | null {
    this.ensure();
    const ix = this.index!, N = ix.items.length; if (!N) return null;
    const qt = Array.from(new Set(tokenize(query))); if (!qt.length) return null;
    const wt = (t: string) => (current && current.has(t) ? 2 : 1);
    const idfOf = (l: number[]) => { const d = l.length / 2; return Math.log(1 + (N - d + 0.5) / (d + 0.5)); };
    // A word that matters more (rarer) counts more for coverage; a word that exists nowhere counts as the most important miss.
    const idfFor = (t: string) => { const l = ix.post.get(t); return l ? idfOf(l) : Math.log(1 + N); };
    const totalW = qt.reduce((sum, t) => sum + wt(t) * idfFor(t), 0);
    const k1 = 1.5, b = 0.75;
    // The most informative word of the question (the rarest one) MUST be in the matched item.
    // Otherwise "write a function to reverse a string" would match some other function that also says "write ... function ... string".
    let key = '', keyScore = -1;
    for (const t of qt) { const sc = wt(t) * idfFor(t); if (sc > keyScore) { keyScore = sc; key = t; } }
    const keyPost = ix.post.get(key);
    if (!keyPost) return null;                              // that word is not in the data at all
    // Follow-up: every word of the NEW question must be in the matched item ("synonyms" must not turn into a definition).
    const required: number[][] = [];
    if (current) for (const t of current) { if (!qt.includes(t)) continue; const l = ix.post.get(t); if (!l) return null; required.push(l); }
    const score = new Map<number, number>(), hits = new Map<number, number>();
    const add = (id: number, f: number, w: number, idf: number) => {
      score.set(id, (score.get(id) || 0) + w * idf * (f * (k1 + 1)) / (f + k1 * (1 - b + b * ix.len[id] / ix.avg)));
      hits.set(id, (hits.get(id) || 0) + w * idf);
    };
    const terms = qt.map(t => ({ t, l: ix.post.get(t) })).filter((x): x is { t: string; l: number[] } => !!x.l);
    const COMMON = 5000;                                   // words in more than 5000 items (e.g. "meaning") are not scanned fully
    const rare = terms.filter(x => x.l.length / 2 <= COMMON), common = terms.filter(x => x.l.length / 2 > COMMON);
    const scan = rare.length ? rare : terms;               // if every word is common, scan them all
    for (const { t, l } of scan) {
      const w = wt(t), idf = idfOf(l);
      for (let i = 0; i < l.length; i += 2) add(l[i], l[i + 1], w, idf);
    }
    if (rare.length) for (const { t, l } of common) {      // look the common words up only for the candidates (binary search)
      const w = wt(t), idf = idfOf(l);
      for (const id of Array.from(score.keys())) { const at = findPost(l, id); if (at >= 0) add(id, l[at + 1], w, idf); }
    }
    const adjOf = (id: number) => {
      // A Q&A item whose question is much longer than the user's question is a pasted-text task
      // (e.g. "is this review positive?" + a whole review). Search can't answer those, so skip them.
      if (!ix.items[id].d && ix.len[id] > qt.length * 3 + 8) return -1;
      if (findPost(keyPost, id) < 0) return -1;
      for (const l of required) if (findPost(l, id) < 0) return -1;
      const cov = hits.get(id)! / totalW; return score.get(id)! * cov * cov;   // reward items that match MORE of the question
    };
    let best = -1, bestAdj = 0;
    score.forEach((_, id) => { const adj = adjOf(id); if (adj > bestAdj) { bestAdj = adj; best = id; } });
    const bestCov = best < 0 ? 0 : hits.get(best)! / totalW;
    if (best < 0 || bestCov < 0.7) return null;           // must match most of the question's words (raise to be stricter)
    // Ambiguous question? e.g. "its atomic number?" fits 118 different elements equally well -> do not guess.
    const tied = new Set<number>();
    score.forEach((_, id) => { if (adjOf(id) >= bestAdj * 0.97 && hits.get(id)! / totalW >= 0.7) tied.add(ix.qh[id]); });
    if (tied.size > 8) return null;
    const it = ix.items[best];
    return { content: it.a, file: it.file, confidence: Math.round(bestCov * 100) / 100 };
  }
}
export const datasetAI = new DatasetAI();
export default DatasetAI;
