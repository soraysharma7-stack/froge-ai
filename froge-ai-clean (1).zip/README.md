# FROGÉ AI

Run locally:
1. Install Node.js (LTS).
2. npm install
3. npm run dev
4. Open http://localhost:3000

The AI answers only from the files in data/datasets/ (see .env: DATASET_ONLY=true).
Add a .jsonl, .json, .txt or .md file there and ask again - no restart needed.
Big parquet files: convert first with: python tools/parquet_to_jsonl.py file.parquet
Architecture notes: docs/FROGE_SYSTEM_ARCHITECTURE.md

## Datasets and tools
- `npm run data:fetch -- list` : ready-made Hugging Face datasets (code, agents, reasoning). `npm run data:import -- file.parquet` for your own files.
- `npm run eval:make | eval:run | eval:pdf` : 7000-question self-check (ready, not run).
- `tools/corpus/` : builds the ~0.5 GB Wikipedia / web / books / recipes corpus.
- `training/` : fine-tune a real model (use a free Colab GPU).
- Full guide with licences: `docs/DATASETS.md`.
- `npm run data:import -- book.pdf` : add a PDF (also .txt, .csv, .parquet).
- `docs/SECURITY.md` : what is open in the community feature and how to secure it.
