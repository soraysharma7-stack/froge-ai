Extra datasets (NOT read by the Dataset AI; use them for training or other tools):
- sentiment.jsonl      2,000 movie reviews labelled positive/negative
- math.jsonl           15,000 generated maths problems with step-by-step solutions
- word_ids.csv         147,478 WordNet words with ID numbers
- english_words_600962.txt   600,962 English words; line number minus 1 is the word ID (same order as the PDF)
