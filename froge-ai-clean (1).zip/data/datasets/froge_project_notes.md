# FROGÉ project notes (summary of the build chat)

How to run the FROGÉ app: install Node.js (LTS), open the app folder in VS Code, run npm install once, then run npm run dev, and open http://localhost:3000 in the browser. Press Ctrl+C in the terminal to stop the app.

What is the Dataset AI: it is a small AI inside the app that answers only from the dataset files in the data/datasets folder. It needs no outside model, no GPU and no internet. It searches the files with BM25 keyword ranking and returns the best matching answer.

How to add a dataset: put a .jsonl, .json, .txt or .md file in data/datasets. The app notices new or changed files automatically, so no restart is needed. For .jsonl use one JSON object per line with a question and an answer, for example instruction and response.

What the Dataset AI cannot do: it cannot write new answers, reason, combine facts, do maths that is not in a file, or classify new text such as sentiment. If nothing matches well it says that it does not have that in its dataset files. A better and larger dataset gives better answers.

Why did the AI reply with Deep First-Principles Reasoning template text: that reply came from a fixed template function in frogeBrainEngine.ts that only inserted the user's words. It was not a real model. The Dataset AI step now runs before those templates, and DATASET_ONLY=true in the .env file stops the templates from being used.

DATASET_ONLY setting: put DATASET_ONLY=true in the .env file in the main app folder. Do not set FROGE_MODEL_ENDPOINT at the same time, because then server.ts sends questions to that model and the Dataset AI is skipped.

Google AI Studio file limit: AI Studio rejects any file over 30 MB, for example a big train-00000-of-00001.parquet dataset. Keep big datasets on your own computer in the data/datasets folder, not inside AI Studio. Use tools/parquet_to_jsonl.py to convert a parquet file into small .jsonl files first.

Hardware plan: a 4 GB RAM computer with an i3 CPU and no GPU can run only very small models such as qwen2.5:0.5b or llama3.2:1b through Ollama. Fine-tuning needs a GPU, so train on free Google Colab or Kaggle and then run the result locally.

Using a real local model instead: install Ollama, run ollama pull qwen2.5:0.5b, then set FROGE_MODEL_ENDPOINT=http://127.0.0.1:11434/v1 and FROGE_MODEL=qwen2.5:0.5b in the .env file. In frogeModelGateway.ts raise timeoutMs to 300000 so long answers are not cut off.

Vocabulary lists that were made: the GPT-2 tokenizer vocabulary has 50,257 tokens with IDs 0 to 50256 (PDF in public/assets/aistudio). A 600,962 word English list is in data/extra/english_words_600962.txt where the line number is the ID. A WordNet word list of 147,478 words with IDs is in data/extra/word_ids.csv.

How an LLM predicts the next token: the text is split into tokens with ID numbers, each token becomes a vector, the model gives a score (logit) to every token in its vocabulary, softmax turns the scores into probabilities, and one token is chosen by taking the highest or sampling with a temperature. The chosen token is added and the process repeats.

Datasets included in this app: chat_instructions.jsonl with about 33,700 question and answer pairs, words.jsonl with about 207,000 WordNet dictionary entries, science_curated.jsonl with chemical elements, constants, units, formulas and science definitions, science_wordnet.jsonl with scientific terms from WordNet, and the original FROGÉ curriculum and alignment files.

Memory use: with all datasets loaded the Dataset AI uses roughly 500 MB of RAM. On a 4 GB computer delete or move words.jsonl out of data/datasets if memory is tight.

Security warning: the firestore.rules file in this app lets users delete and edit other people's posts and profiles because it uses OR where AND is needed. Fix the rules before sharing the app with real users.

Previous chat memory: the Dataset AI looks at the previous messages of the chat. A follow-up such as and its atomic number, what about iron, or give me synonyms for it is joined with the previous question before searching, so it answers about the same topic. If the question is too vague, for example its atomic number with no earlier question, it says that it does not know instead of guessing.

Step-by-step calculator: pure maths questions such as 47 x 23, (12 + 3) * 4 - 5, 20% of 150, 2^10, sqrt(144) or what is 15 plus 7 times 2 are solved with shown steps by the built-in calculator, before the dataset search. It does not use a model and it never guesses.

Adding Hugging Face datasets: run npm run data:fetch -- list to see ready-made ones (code_instructions, magicoder_evol, agentinstruct, gsm8k, bespoke_stratos, openr1_math). Run npm run data:fetch -- code_instructions to download and import one. For a file you downloaded yourself use npm run data:import -- file.parquet. Parquet, csv, json and jsonl are supported.

Training data versus search data: files in data/datasets are searched by the AI. Files in data/training, such as AgentInstruct tool-use and reasoning traces, are only for fine-tuning a model with training/train.py because they are too long to search.

Self-check with 7000 questions: npm run eval:make creates the questions with correct answers, npm run eval:run scores the AI, and npm run eval:pdf writes a PDF with each question and its answer below it. Use the holdout option for an honest test on questions the AI has never seen. It is ready in the code but it has not been run.

Complex reasoning: the built-in AI finds stored answers and calculates, it does not reason about new problems. For real reasoning, import reasoning datasets, fine-tune a small model with training/train.py on a free Colab GPU, run it with Ollama and set FROGE_MODEL_ENDPOINT in the .env file.

Importing PDF files: run npm run data:import -- book.pdf --max 500000. The text of a text PDF is cut into pieces of about 1200 characters and saved in data/datasets, then the AI can search it. Install poppler (pdftotext) for very large PDFs. Picture-only scanned PDFs need OCR first.


Security of the community feature: the community uses a fake local user id, so firestore.rules is open on purpose. A secure version firestore.rules.secure is ready but needs Firebase anonymous sign-in first. See docs/SECURITY.md.

